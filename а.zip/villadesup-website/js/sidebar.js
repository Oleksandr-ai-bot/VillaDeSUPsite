// Sidebar JavaScript for VilladeSUP Website

document.addEventListener('DOMContentLoaded', () => {
    // Получение DOM элементов
    const sidebar = document.querySelector('.sidebar');
    const menuButton = document.getElementById('menuButton');
    const closeSidebarBtn = document.getElementById('closeSidebar');
    const overlay = document.getElementById('overlay');
    const content = document.querySelector('.content');

    // Проверка наличия необходимых элементов
    if (!sidebar || !menuButton || !closeSidebarBtn || !overlay || !content) {
        console.error('Не найдены необходимые элементы для бокового меню');
        return;
    }

    // Функция открытия бокового меню
    function openSidebar() {
        sidebar.classList.add('open');
        overlay.classList.add('active');
        content.classList.add('sidebar-open');
        menuButton.classList.remove('visible');

        // Отключение прокрутки для мобильных устройств
        if (window.innerWidth < 768) {
            document.body.style.overflow = 'hidden';
        }
    }

    // Функция закрытия бокового меню
    function closeSidebar() {
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
        content.classList.remove('sidebar-open');

        // Показать кнопку меню с небольшой задержкой
        setTimeout(() => {
            menuButton.classList.add('visible');
        }, 300);

        // Включение прокрутки
        document.body.style.overflow = 'auto';
    }

    // Добавление обработчиков событий
    menuButton.addEventListener('click', openSidebar);
    closeSidebarBtn.addEventListener('click', closeSidebar);
    overlay.addEventListener('click', closeSidebar);

    // Показать кнопку меню при загрузке
    setTimeout(() => {
        menuButton.classList.add('visible');
    }, 500);

    // Закрытие меню по клавише Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && sidebar.classList.contains('open')) {
            closeSidebar();
        }
    });

    // Подсветка активного пункта меню
    setActiveMenuItem();

    // Добавление эффектов для пунктов меню
    addMenuItemEffects();
});

// Подсветка активного пункта меню
function setActiveMenuItem() {
    const currentPath = window.location.pathname;
    const menuItems = document.querySelectorAll('.sidebar-nav li');

    menuItems.forEach(item => {
        const link = item.querySelector('a');
        if (!link) return;

        const href = link.getAttribute('href');

        item.classList.remove('active');

        // Проверка соответствия текущего пути и ссылки
        if (currentPath.endsWith(href) ||
            (currentPath.endsWith('/') && href === 'index.html') ||
            (currentPath.includes(href) && href !== 'index.html')) {
            item.classList.add('active');
        }
    });
}

// Добавление эффектов для пунктов меню
function addMenuItemEffects() {
    const navItems = document.querySelectorAll('.sidebar-nav a');

    navItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            const icon = item.querySelector('i');
            if (icon) {
                icon.classList.add('fa-bounce');
            }
        });

        item.addEventListener('mouseleave', () => {
            const icon = item.querySelector('i');
            if (icon) {
                icon.classList.remove('fa-bounce');
            }
        });
    });
}