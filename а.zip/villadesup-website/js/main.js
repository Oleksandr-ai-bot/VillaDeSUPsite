// Main JavaScript for VilladeSUP Website

// Инициализация при загрузке DOM
document.addEventListener('DOMContentLoaded', () => {
    // Загрузочный экран
    const loader = document.querySelector('.loader');

    // Скрыть загрузочный экран через 2 секунды
    setTimeout(() => {
        loader.classList.add('hidden');
        // Включить прокрутку после скрытия загрузчика
        document.body.style.overflow = 'auto';
    }, 2000);

    // Инициализация анимаций
    initAnimations();

    // Инициализация копирования IP-адреса
    initCopyIP();

    // Создание фоновых частиц
    createParticles();

    // Создание модального окна
    createModal();

    // Инициализация обработчиков событий для кнопок
    initButtons();

    // Установка статуса сервера
    setServerStatus();
});

// Установка статуса сервера как оффлайн
function setServerStatus() {
    const statusIndicators = document.querySelectorAll('.status-indicator');
    const statusTexts = document.querySelectorAll('.status-text');
    const playerCounts = document.querySelectorAll('.player-count');

    // Установка всех индикаторов в оффлайн
    statusIndicators.forEach(indicator => {
        indicator.classList.remove('online');
        indicator.classList.add('offline');
    });

    // Установка всех текстов в "Оффлайн"
    statusTexts.forEach(text => {
        text.textContent = 'Оффлайн';
    });

    // Установка всех счетчиков игроков в "0/100"
    playerCounts.forEach(count => {
        count.textContent = '0/100';
    });
}

// Инициализация анимаций
function initAnimations() {
    // Анимация элементов при прокрутке
    const animatedElements = document.querySelectorAll('.features-section, .news-section, .join-section, .coming-soon');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('slide-fade-up', 'active');

                // Добавление анимации с задержкой для дочерних элементов
                const staggerItems = entry.target.querySelectorAll('.feature-card, .news-card');
                staggerItems.forEach((item, index) => {
                    setTimeout(() => {
                        item.classList.add('stagger-animation', 'active');
                    }, index * 100);
                });

                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.2
    });

    animatedElements.forEach(element => {
        observer.observe(element);
    });
}

// Инициализация обработчиков кнопок
function initButtons() {
    // Кнопка "Подключиться к серверу" и "Играть сейчас" - скролл к разделу join-section
    const connectButtons = document.querySelectorAll('.primary-btn, .connect-btn');

    connectButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const joinSection = document.querySelector('.join-section');
            if (joinSection) {
                joinSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Кнопка "Узнать больше" - открытие модального окна
    const infoButton = document.querySelector('.secondary-btn');
    if (infoButton) {
        infoButton.addEventListener('click', () => {
            const modal = document.querySelector('.modal');
            if (modal) {
                modal.classList.add('active');
            }
        });
    }

    // Инициализация навигации в футере
    const footerLinks = document.querySelectorAll('.footer-links a');

    footerLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');

            // Если это внутренняя ссылка
            if (href && !href.startsWith('http') && !href.startsWith('#')) {
                e.preventDefault();
                navigateTo(href);
            }
        });
    });
}

// Функционал копирования IP-адреса
function initCopyIP() {
    const copyBtn = document.getElementById('copyBtn');
    const serverIp = document.getElementById('serverIp');
    const copyMessage = document.getElementById('copyMessage');

    if (copyBtn && serverIp && copyMessage) {
        copyBtn.addEventListener('click', () => {
            // Выделение текста
            serverIp.select();
            serverIp.setSelectionRange(0, 99999);

            // Копирование в буфер обмена
            navigator.clipboard.writeText(serverIp.value)
                .then(() => {
                    // Добавление визуального эффекта копирования
                    copyMessage.classList.add('visible');

                    // Добавление анимации кнопки
                    copyBtn.classList.add('copied');

                    // Добавление элемента успешного копирования
                    if (!copyBtn.querySelector('.copy-success')) {
                        const successElement = document.createElement('div');
                        successElement.className = 'copy-success';
                        successElement.innerHTML = '<i class="fas fa-check"></i>';
                        copyBtn.appendChild(successElement);
                    }

                    // Скрытие сообщения через 2 секунды
                    setTimeout(() => {
                        copyMessage.classList.remove('visible');
                        copyBtn.classList.remove('copied');
                    }, 2000);
                })
                .catch(err => {
                    console.error('Ошибка копирования: ', err);
                    copyMessage.textContent = 'Ошибка при копировании';
                    copyMessage.classList.add('visible');

                    setTimeout(() => {
                        copyMessage.classList.remove('visible');
                        copyMessage.textContent = 'IP скопирован!';
                    }, 2000);
                });
        });
    }
}

// Создание фоновых частиц
function createParticles() {
    const content = document.querySelector('.content');
    if (!content) return;

    // Создание контейнера, если его ещё нет
    let particlesContainer = document.querySelector('.particles-background');
    if (!particlesContainer) {
        particlesContainer = document.createElement('div');
        particlesContainer.className = 'particles-background';
        content.appendChild(particlesContainer);
    }

    // Создание частиц
    const particleCount = 50;

    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';

        // Случайный размер
        const size = Math.random() * 3 + 1;
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;

        // Случайная позиция
        const posX = Math.random() * 100;
        const posY = Math.random() * 100;
        particle.style.left = `${posX}%`;
        particle.style.top = `${posY}%`;

        // Случайная прозрачность
        particle.style.opacity = Math.random() * 0.5 + 0.1;

        // Случайная анимация
        const duration = Math.random() * 50 + 10;
        const delay = Math.random() * 5;

        particle.style.animation = `float ${duration}s infinite linear ${delay}s`;

        particlesContainer.appendChild(particle);
    }
}

// Создание модального окна для кнопки "Узнать больше"
function createModal() {
    // Проверка наличия модального окна
    if (document.querySelector('.modal')) return;

    // Создание модального окна
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-body">
                <img src="assets/images/SUP.png" alt="VilladeSUP Logo" class="modal-image">
                <h2 class="modal-title">Добро пожаловать на VilladeSUP!</h2>
                <p class="modal-text">Наш сервер предлагает уникальный игровой опыт в Minecraft. Присоединяйтесь к нам!</p>
                <div class="modal-info">
                    <p><strong>IP-адрес:</strong> freesup.falixsrv.me</p>
                    <p><strong>Статус:</strong> <span class="status-text">Оффлайн</span></p>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    // Обработчик закрытия модального окна
    const closeBtn = modal.querySelector('.close-modal');
    closeBtn.addEventListener('click', () => {
        modal.classList.remove('active');
    });

    // Закрытие по клику вне содержимого
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });

    // Закрытие по клавише Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            modal.classList.remove('active');
        }
    });
}

// Функция для анимированного перехода между страницами
function navigateTo(url) {
    // Создание элемента перехода
    const transition = document.createElement('div');
    transition.className = 'page-transition entering';
    document.body.appendChild(transition);

    // Переход на новую страницу после анимации
    setTimeout(() => {
        window.location.href = url;
    }, 800);
}

// Обработка анимации перехода при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Проверка, является ли это новой загрузкой страницы
    if (performance.navigation.type === 1) {
        const transition = document.createElement('div');
        transition.className = 'page-transition exiting';
        document.body.appendChild(transition);

        setTimeout(() => {
            transition.remove();
        }, 800);
    }
});